<footer class="page-footer section text-center page-footer-hi">
<div class="shell">
  <p class="copyright preffix-xl-70">Zelenka.trade	&#169; <span class="copyright-year"></span>. <a href="privacy-policy.html">Политика конфединциальности</a>
  </p>
</div>
</footer>