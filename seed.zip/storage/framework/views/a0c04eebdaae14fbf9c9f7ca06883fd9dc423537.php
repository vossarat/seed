<?php $__env->startSection('content'); ?>



<section class="section bg-white text-center">



    <div class="shell">

        <div class="range range-xs-center range-md-left">
            <div class="cell-xs-12 cell-md-4">

                <form action="<?php echo e(route('order.create')); ?>">
                    <button type="submit" class="button button-effect-ujarak button-block button-default-outline">
                        Добавить заявку
                    </button>

                </form>

            </div>
        </div>

		
		<?php if(Session::has('message')): ?>
		<div class="alert alert-success">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			<?php echo e(Session::get('message')); ?>

		</div>
		<?php endif; ?>
		

        <h3>
            Заявки
        </h3>

        <div class="range range-xs-center">           
        	<?php echo $__env->make('order.filter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        
        <div class="range range-xs-center">
            <div class="cell-xs-12">

                <div class="table-custom-responsive order-table">
                    <table class="table-custom table-custom-striped table-custom-primary">
                        <tbody>
                            <?php $__currentLoopData = $viewdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="order-table-row">
                                
                                <td>
                                <div class="row">
	                                <div class="col-xs-6">
	                                	<?php echo e(date('d.m.Y',strtotime($order->created_at))); ?>

	                                </div>
	                                <div class="col-xs-6">
	                                	<?php echo e($order->price); ?> тенге
	                                </div>
                                </div>
                                 <div class="row">
	                                <div class="col-xs-12">
	                                	<?php if(Auth::check() && Auth::user()->id == $order->user_id): ?>
		                                    	Ваша заявка</br>
		                                <?php endif; ?>	                                    	
	                                	<a class="toogle-order-detailed" href="<?php echo e(route('order.edit', $order->id)); ?>"><?php echo e('Заявка на '.$order->corn['name']); ?>, <?php echo e($order->count . ' тонн'); ?></a>
	                                <div class="order-detailed">
                                		<ul>
                                			<li>Упаковка: <?php echo e($packs->find($order->pack_id ? $order->pack_id : '1')->name); ?></li>
                                			<li><?php echo e($loadprices->find($order->loadprice_id ? $order->loadprice_id : '1')->name); ?>, <?php echo e($order->auction ? 'Торг' : 'Без торга'); ?></li>
                                			<li>Разместил: <?php echo e($order->user->name); ?></li>
                                		</ul>
                                	</div>
	                                </div>
                                </div>
                                
                                
                                	
                                	
                                	
	                                
                                
                                </td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                </div>
                <div class="divider-edgewise"></div>
            </div>
        </div>
    </div>
</section>

<div class="range range-xs-center">
<?php echo e($viewdata->appends([
		'filter' => 'filter',		
		'arrcorns' => $selected_corns,
		'filterByPriceMin' => $filterByPriceMin,		
		'filterByPriceMax' => $filterByPriceMax,		
		'filterByRegion' => $filterByRegion,		
	])->links()); ?>

</div>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/project.scripts.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>