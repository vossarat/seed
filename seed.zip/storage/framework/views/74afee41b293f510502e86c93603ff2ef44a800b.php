

<li>
    <a href="#">
        <?php echo e($username); ?>

    </a>
    <ul class="rd-navbar-dropdown">
        <?php if( Auth::check() ): ?>
			<li>
				<?php if($routeprofile === 'create'): ?>
					<a href="<?php echo e(route('trader.create')); ?>">
						<?php echo e($titleprofile); ?>

					</a>
				<?php else: ?>
					<a href="<?php echo e(route('trader.edit', $trader_id)); ?>">
						<?php echo e($titleprofile); ?>

					</a>
				<?php endif; ?>
			</li>
			
			<li>
				<?php if($routeprofileFarmer === 'create'): ?>
					<a href="<?php echo e(route('farmer.create')); ?>">
						<?php echo e($titleprofileFarmer); ?>

					</a>
				<?php else: ?>
					<a href="<?php echo e(route('farmer.edit', $farmer_id)); ?>">
						<?php echo e($titleprofileFarmer); ?>

					</a>
				<?php endif; ?>
			</li>
			
			<?php if( Auth::user()->id === 1 ): ?>
			<li>
                <a href="/dashboard">Админ.панель</a>
            </li>
            <?php endif; ?>

			<li>
	            <a href="<?php echo e(route('logout')); ?>"
	                onclick="event.preventDefault();
	                	document.getElementById('logout-form').submit();">
	                <span class="fa fa-sign-out"></span> Выход
	            </a>
	            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
	                <?php echo e(csrf_field()); ?>

	            </form>
	        </li>						
		<?php else: ?>
			<li>
				<a href="/login">
					Войти в систему
				</a>
			</li>
			<li>
				<a href="/register">
					Регистрация
				</a>
			</li>
	   	<?php endif; ?>
    </ul>
</li>