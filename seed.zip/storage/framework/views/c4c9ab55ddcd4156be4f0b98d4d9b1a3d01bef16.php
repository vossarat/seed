<div class="form-group">
<div class="col-xs-12">
	<?php if($filter): ?>
		<a href="<?php echo e(route('order.index')); ?>" class="button button-effect-ujarak button-block button-default-outline">
        	Очистить Фильтр
        </a>
    <?php else: ?>			    	
        <a class="button button-effect-ujarak button-block button-default-outline toogle-order-filter">
        	Фильтр
        </a>
    <?php endif; ?>
</div> 
</div>



<div id="order-filter" class="cell-xs-12">	
	<form>
		<input type="hidden" name="filter" value="filter"/>
		
		<div class="form-group">
			<label>По культуре</label>		
			
			<select type="hidden" id="select-corns"  name="arrcorns[]" size="5" multiple="multiple" >
				<?php $__currentLoopData = $corns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if(isset($selected_corns)): ?>
						<option <?php echo e(in_array($item->id, $selected_corns )  ? 'selected' : ''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
					<?php else: ?>
					<option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>			
			</select>
		</div>
		
		<div class="form-group">
			<label>По цене</label>
			<input type="text" name="filterByPriceMin" value="<?php echo e($filterByPriceMin); ?>" placeholder="от"/>
			<input type="text" name="filterByPriceMax" value="<?php echo e($filterByPriceMax); ?>" placeholder="до"/>
		</div>
		
		<div class="form-group">
		
			<label>Район</label>		
		
			<select style="width: auto;"  name="filterByRegion">
				<option value="0">Все районы</option>
				<?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $filterByRegion ? 'selected' : ''); ?>>
							<?php echo e($item->name); ?>

						</option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>			
			</select>

		</div> 
		
		<input type="submit" value="Установить фильтр"/>
	</form>
</div>