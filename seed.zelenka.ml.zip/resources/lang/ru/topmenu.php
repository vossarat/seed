<?php
return [
    'mainpage' => 'Главная',
    'addorder' => 'Добавить заявку',
    'elevators' => 'Элеваторы',
    'news' => 'Новости',
    'feedback' => 'Обратная связь',
    'help' => 'Помощь',
];