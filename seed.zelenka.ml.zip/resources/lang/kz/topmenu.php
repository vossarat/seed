<?php
return [
    'mainpage' => 'Басты бет',
    'addorder' => 'Өтінімді қосу',
    'elevators' => 'Элеваторлар',
    'news' => 'Жаңалықтар',
    'feedback' => 'Кері байланыс',
    'help' => 'Көмек',
];