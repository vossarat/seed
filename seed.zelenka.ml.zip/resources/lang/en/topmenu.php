<?php
return [
    'mainpage' => 'Main page',
    'addorder' => 'Add order',
    'elevators' => 'Elevators',
    'news' => 'News',
    'feedback' => 'Feedback',
    'help' => 'Help',
];