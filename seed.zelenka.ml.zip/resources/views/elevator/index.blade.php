@extends('layouts.template')

@section('tableprice')
    @include('layouts.tableprice')
@endsection


@section('content')



<section class="section bg-white text-center">

<div class="shell">

    <h3>
        Карта элеваторов
    </h3>
    
    <div class="range range-xs-center">           
    	@include('elevator.filter')
    </div>{{-- /range range-xs-center --}}
    
    
    <div class="order-table">

            @foreach($viewdata as $elevator)
            <div class="row order-table-row">
            	<div class="row">
                    <div class="col-xs-2 col-fav-elevator">
                    	{{-- 
                    	$elevator->fav - возращает звезду
                    	закрашенную или нет в зависимости от того избран или нет пользователь
                    	 --}}
                    	<span id="fav-{{ $elevator->id }}" class="fav {{ $elevator->fav }}"></span>
                    	@if(Auth::check())
                        <!--<input type="checkbox" class="fav" id="fav-{{ $elevator->id }}" {{ $elevator->fav }}/>-->
                        @endif
                    </div>
                    <div class="col-xs-10">
                    	{{ $elevator->title }}
                    </div>
                </div>
            </div>
            @endforeach            

    </div>      
    
</div>
<div class="range range-xs-center">
{!! $viewdata->appends([
		'filter' => 'filter',		
		'arrcorns' => $selected_corns,		
		'filterByPriceMin' => $filterByPriceMin,		
		'filterByPriceMax' => $filterByPriceMax,		
	])->links() !!}
</div>
</section>

@push('scripts')
<script src="{{ asset('js/project.scripts.js') }}"></script>
<script>
$(document).ready(function() {
        /*$( ".fav" ).change(function( event ) {
                var elevator_id = $(this).attr('id').substring(4);
                {{-- // по умолчанию удалить из избранных --}}
                var url_action = "/api/fav/remove/"+{{ Auth::id() }}+"/"+elevator_id ; 
                if( $(this).prop("checked") ) {
					 {{-- // если чекнутый то добавляем в избранные --}}
					 url_action = "/api/fav/add/"+{{ Auth::id() }}+"/"+elevator_id ;
				}
				console.log( 'url_action = '+url_action );
                $.ajax({
                        url: url_action,
                    });
            });*/
            
        $( ".fav" ).click(function( event ) {
                var elevator_id = $(this).attr('id').substring(4);
                console.log( 'elevator_id = '+elevator_id );
                {{-- // по умолчанию удалить из избранных --}}
                var url_action = "/api/fav/remove/"+{{ Auth::id() }}+"/"+elevator_id ; 
                if( $(this).hasClass("fa-star-o") ) {
					 {{-- // если звезда не закрашена то добавляем в избранные --}}
					 url_action = "/api/fav/add/"+{{ Auth::id() }}+"/"+elevator_id ;
					 $(this).removeClass("fa-star-o");
					 $(this).addClass("fa-star"); // ставим избранное
				} else {
					$(this).removeClass("fa-star"); // убираем избранное
					$(this).addClass("fa-star-o");
				}
				console.log( 'url_action = '+url_action );
                $.ajax({
                        url: url_action,
                    });
            });
    });
</script>
@endpush	

@endsection