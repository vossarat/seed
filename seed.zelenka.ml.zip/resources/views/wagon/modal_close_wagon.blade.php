<!-- HTML-код модального окна -->
<div id="close-wagon-modal" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- Заголовок модального окна -->
      <div class="modal-header">
        <h4 class="modal-title">Хотитите завершить заявку?</h4>
      </div>
      <!-- Основное содержимое модального окна -->
      <div class="modal-body modal-wagon-content">
        Вы действительно хотитите завершить заявку ?
      </div>
      <!-- Футер модального окна -->
      <div class="modal-footer row">        
        <button type="button" name="" class="btn btn-primary yes-close-modal col-xs-4 col-xs-offset-2" data-dismiss="modal">Завершить</button>
        <button type="button" class="btn btn-default col-xs-4 col-xs-offset-1" data-dismiss="modal">Отмена</button>
      </div>
    </div>
  </div>
</div>