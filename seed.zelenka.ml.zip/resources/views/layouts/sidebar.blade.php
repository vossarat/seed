<ul class="nav">
	<li>
		<a href="/user">
			<i class="fa fa-table fa-4x"></i>
			<p>Пользователи</p>
		</a>
	</li>

	<li>
		<a href="">
			<i class="fa fa-file-text-o fa-4x"></i>

			<p>Трейдеры</p>
		</a>
	</li>
	
	<li>
		<a href="">
			<i class="fa fa-wrench fa-4x"></i>

			<p>Установки</p>
		</a>
	</li>
	
</ul>