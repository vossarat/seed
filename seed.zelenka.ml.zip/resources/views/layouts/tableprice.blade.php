<section class="section text-center visible-xs">
	<div class="shell rates-mobile">
		@foreach($rates as $rate)
			{{ $rate['title'].':'. $rate['description'] }}&nbsp;
		@endforeach
	</div>	
</section>

<section class="table-price section text-center">
<div class="shell">
  <p class="">ТАБЛИЦА ЦЕН на зерно</p>
  <p class="">АО "НК "ПРОДКОРПОРАЦИЯ"</p>
  <p class="">обновлена 06.09.2018</p>
   	
	  <div class="row">		    	
			<div class="col-xs-8 col-xs-offset-2">		    	
				<a class="button button-block button-default-outline button-tableprice-view">
					Просмотреть
				</a>
			</div>
		</div>
	</div>
	
</section>

<section class="section text-center hidden-xs">
	<form action="{{ route('order.create') }}">
	    <button type="submit" class="button button-effect-ujarak button-block button-primary">
	        Добавить заявку
	    </button>
	</form>	
</section>
