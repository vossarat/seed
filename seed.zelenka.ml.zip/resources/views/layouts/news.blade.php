<section class="section section-sm bg-gray-bright context-dark moderno-footer">
    <div class="shell">
        <div class="range range-40">
            <div class="cell-md-3 cell-sm-5">
                <div class="preffix-xl-85 footer-item-custom footer-item-custom-1" style="max-width: 274px">
                    <h6 class="text-spacing-200 text-uppercase font-base">
                        Новости
                    </h6>
                    <div class="divider-default">
                    </div>
                    <div class="post-minimal-wrap">
                        <a class="post-minimal" href="#">
                            <div class="unit unit-horizontal unit-middle">

                                <div class="unit-body">
                                    <p>
                                        <span>
                                            30.08.2018
                                        </span>
                                        	Тарифы на оказание услуг хлебоприемными предприятиями
                                    </p>
                                </div>
                            </div>
                        </a>
                        <a class="post-minimal" href="#">
                            <div class="unit unit-horizontal unit-middle">

                                <div class="unit-body">
                                    <p>
                                        <span>
                                            22.08.2018
                                        </span>
                                        	Реализация подсолнечного нерафинированного масла и жмыха 
                                    </p>
                                </div>
                            </div>
                        </a>
                        <a class="post-minimal" href="#">
                            <div class="unit unit-horizontal unit-middle">

                                <div class="unit-body">
                                    <p>
                                        <span>
                                            17.08.2018
                                        </span>
                                        	Условия продажи зерна Продкорпорации не изменились 
                                    </p>
                                </div>
                            </div>
                        </a>
                    </div>
                     <div class="divider-default"></div>
                    
                </div>
            </div>
            
           
            
            <div class="cell-md-3 cell-sm-5 text-center">
                <div class="preffix-xl-45 footer-item-custom footer-item-custom-2" style="max-width: 327px">
                    <a href="#">
	                    <h6>
	                        НА ГЛАВНУЮ
	                    </h6>
                    </a>
                    <div class="divider divider-nav"></div>
                    
                    <a href="#">
	                    <h6>
	                        ДОБАВИТЬ ЗАЯВКУ
	                    </h6>
                    </a>
                    <div class="divider divider-nav"></div>
                    
                    <a href="#">
	                    <h6>
	                        МОЙ  ПРОФИЛЬ
	                    </h6>
                    </a>
                    <div class="divider divider-nav"></div>
                    <a href="#">
	                    <h6>
	                        О НАС
	                    </h6>
                    </a>
                </div>
            </div>
            
        </div>
    </div>
</section>