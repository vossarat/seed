<section class="section section-lg bg-white text-center">
    <div class="shell">
        <div class="range range-xs-center range-60 range-lg-200">
            <div class="cell-xs-12">
                <div class="block-center" style="max-width: 520px">
                <h2>
                    Заголовок
                </h2>
                //
                </div>
            </div>
        </div>
    </div>
</section>