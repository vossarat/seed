<p>Письмо от пользователя: {{ $viewdata['name'] }}</p>
<p>Телефон: {{ $viewdata['phone'] }}</p>
<p>Email: {{ $viewdata['email'] }}</p>
<p>Текст сообщения: {{ $viewdata['message'] }}</p>