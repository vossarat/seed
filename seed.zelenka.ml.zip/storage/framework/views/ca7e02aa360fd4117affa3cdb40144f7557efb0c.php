<?php $__env->startSection('content'); ?>

<section class="section section-lg bg-white text-center">
    <div class="shell">
        <div class = "row">
            <div class = "col-xs-12 col-sm-8 col-sm-offset-2 help-content">

                <h2>
                    <?php echo e($viewdata->title); ?>

                </h2>
                <!--<p class="help-section text-left">
                    Регистрация на Zelenka.trade
                </p>-->
                <p style="text-align: justify; text-justify: inter-word;">                   
					<?php echo $viewdata->description; ?>

                </p>
                

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template-100', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>