<!-- RD Navbar-->
<div class="rd-navbar-wrap">
    <nav class="rd-navbar rd-navbar-widget" data-layout="rd-navbar-fixed" data-sm-layout="rd-navbar-fixed" data-md-layout="rd-navbar-static" data-md-device-layout="rd-navbar-fixed" data-lg-layout="rd-navbar-static" data-lg-device-layout="rd-navbar-static" data-md-stick-up-offset="40px" data-lg-stick-up-offset="40px" data-stick-up="true" data-sm-stick-up="true" data-md-stick-up="true" data-lg-stick-up="true">
        
        
        
        
        <div class="rd-navbar-collapse-toggle user-menu" data-rd-navbar-toggle=".rd-navbar-collapse">           
             <a href="#user-menu" style="color: #000;"><span class="fa fa-user fa-2x"></span></a>
        </div>
        
    
       <section>
        <div class="rd-navbar-top-panel">
            <div class="rd-navbar-top-panel-inner">
                <!-- RD Navbar Brand-->
                <div class="rd-navbar-brand">
                    
                    <a class="brand-name" href="/">
                    	    	
                     
                        <img src="/images/logo.png" alt="" width="622" height="184"/>
 						
                    </a> 
                <h1>ОНЛАЙН ПОКУПКА И ПРОДАЖА ЗЕРНА В КАЗАХСТАНЕ</h1>   
                </div>
                
                
                <div class="rd-navbar-collapse hidden-xs">
                    <ul class="list-spreader list-spreader-xl">
                        <li>
                            <div class="unit-link-with-icon unit unit-spacing-xs unit-horizontal">
                                <div class="unit-body">
                                    <p style="color: #f8a63d; ">
                                        С нами работают
                                    </p>
                                    <p>
                                        Трейдеры : <?php echo e($cntTrader); ?>

                                    </p>
                                    <p>
                                        Производители СХП : <?php echo e($cntFarmer); ?>

                                    </p>
                                    <p>
                                        Элеваторы : <?php echo e($cntElevator); ?>

                                    </p>
                                    
                                    
                                </div>
                            </div>
                        </li>                        
                        <li>
                            <div class="unit-link-with-icon unit unit-spacing-xs unit-horizontal">
                                
                                <div class="unit-body">
                                   
								
										 
                                    <?php $__currentLoopData = $rates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p>
                                        <?php echo e($rate['title'].' : '. $rate['description']); ?>

                                    </p>                                  
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="unit-link-with-icon unit unit-spacing-xs unit-horizontal">
                                <div class="unit-body">
                                    <p>
                                        Всего заявок на сайте : <?php echo e($cnt_orders); ?>

                                    </p>
                                    <p>
                                        Активных : <?php echo e($cnt_active_orders); ?>

                                    </p>
                                    
                                    
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="unit-link-with-icon unit unit-spacing-xs unit-horizontal">
                                <div class="unit-body">                                	
							        <!-- Секция меню  пользователя -->
							        <?php if( Auth::check() ): ?>
								        <?php $__env->startSection('usermenu'); ?>
								        	<?php echo $__env->make('layouts.usermenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
								        <?php echo $__env->yieldSection(); ?>
							        <?php else: ?>
							        	<p>
											<a href="/login">
												Войти в систему
											</a>
										</p>
										<p>
											<a href="/register">
												Регистрация
											</a>
										</p>
										<p>
											<a href="/setlocale/ru">RU</a>
											<a href="/setlocale/kz">KZ</a>
											<a href="/setlocale/en">EN</a>
										</p>
							        <?php endif; ?>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
                
                
            
            
            </div>
        </div>
        </section>
        <section>
        <div class="rd-navbar-inner rd-navbar-inner-bottom topmenu-navbar">
            <!-- RD Navbar Panel-->
            <div class="rd-navbar-panel">
                <!-- RD Navbar Toggle-->
                <button class="rd-navbar-toggle" data-rd-navbar-toggle=".rd-navbar-nav-wrap">
                    <span>
                    </span>
                </button>
                <!-- RD Navbar Brand-->
                <div class="rd-navbar-brand">
                    <a class="brand-name" href="/">
                    	
                        
                        <img src="/images/logo.png" alt="" width="522" height="84"/>
                        <h1 style="font-size: 2vw;">ОНЛАЙН ПОКУПКА И ПРОДАЖА ЗЕРНА В КАЗАХСТАНЕ</h1>
                        
                    </a>
                </div>

                <?php $__env->startSection('topmenu'); ?>
                <?php echo $__env->make('layouts.topmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->yieldSection(); ?>

            </div>
        </div>
        </section>
    </nav>
</div>

<nav id="user-menu">
	<ul id="panel-menu">
		<?php $__env->startSection('usermenumobile'); ?>
        	<?php echo $__env->make('layouts.usermenumobile', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldSection(); ?>
	</ul>
</nav>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
	$(function() {
		$('.usermenu').on('show.bs.dropdown', function () {
			$( ".topmenu-navbar" ).addClass('topmenu-navbar-close');
		});
		
		$('.usermenu').on('hide.bs.dropdown', function () {
		  	$( ".topmenu-navbar" ).removeClass('topmenu-navbar-close');
		})
	});
	
</script>
<?php $__env->stopPush(); ?>