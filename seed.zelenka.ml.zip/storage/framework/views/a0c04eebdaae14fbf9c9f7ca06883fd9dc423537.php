<?php $__env->startSection('tableprice'); ?>
    <?php echo $__env->make('layouts.tableprice', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<section class="section bg-white text-center">



    <div class="shell">

        <div class="range range-xs-center range-md-left">
            <div class="cell-xs-12 cell-md-4">

                <form action="<?php echo e(route('order.create')); ?>">
                    <button type="submit" class="button button-effect-ujarak button-block button-primary">
                        Добавить заявку
                    </button>
                </form>

            </div>
        </div>

		
		<?php if(Session::has('message')): ?>
		<div class="alert alert-success">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			<?php echo e(Session::get('message')); ?>

		</div>
		<?php endif; ?>
		

        <h3>
            Заявки
        </h3>

        <div class="row-filter">
        
        	<?php echo $__env->make('order.filter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        	
        </div>
        
                
          
            
            <div class="order-table">

                            <?php $__currentLoopData = $viewdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row order-table-row">                                
                                <?php if(Auth::check() && Auth::user()->id == $order->user_id): ?>
                                <div class="row">
	                                <div class="col-xs-6">
	                                	<a href="#">Редактировать</a>
	                                </div>
	                                <div class="col-xs-6">
	                                	<a href="#">Завершить</a>
	                                </div>
                                </div>
                                <?php endif; ?>
                                
                                <div class="row">
	                                <div class="col-xs-4">
	                                	<?php echo e(date('d.m.Y',strtotime($order->created_at))); ?>

	                                </div>
	                                <div class="col-xs-5">
	                                	<?php if(Auth::check() && Auth::user()->id == $order->user_id): ?>
		                                    	Ваша заявка
		                                <?php endif; ?>
	                                </div> 
	                                <div class="col-xs-3">
	                                	<span class="fa fa-eye"></span> 
	                                	<span id="views_<?php echo e($order->id); ?>" class="views_order"><?php echo e($order->views); ?></span>
	                                </div>
                                </div>
                                 <div class="row">
	                                <div class="col-xs-12">
	                                	<a class="toogle-order-detailed" href="/api/views_order/<?php echo e($order->id); ?>" order-id=<?php echo e($order->id); ?>><?php echo e('Заявка на '.$order->corn['name']); ?>, <?php echo e($order->count . ' тонн'); ?>, <?php echo e($order->price); ?> тенге</a>
	                                <div class="order-detailed">
                                		<ul>
                                			<li><u>Упаковка:</u> <?php echo e($packs->find($order->pack_id ? $order->pack_id : '1')->name); ?></li>
                                			<li><?php echo e($loadprices->find($order->loadprice_id ? $order->loadprice_id : '1')->name); ?>, <?php echo e($order->auction ? 'Торг' : 'Без торга'); ?></li>
                                			
                                			<li><u>Элеваторы:</u>
                                				<?php $__currentLoopData = $order->elevators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $elevator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                					<?php echo e($elevator->title); ?>;
                                				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                			</li>
                                			<li><u>Подробные параметры</u> </li>
                                			<li>
                                			&nbsp;&nbsp;&bull;Класс или сорт продукции: 
                                			<?php echo e($order->sort_standart ? 'Стандарт;' : ''); ?> 
                                			<?php echo e($order->sort_other ? 'Другое;' : ''); ?>

                                			<?php echo e($order->sort_gost1 ? 'Гост 1;' : ''); ?>

                                			<?php echo e($order->sort_gost2 ? 'Гост 2;' : ''); ?>

                                			</li>
                                			<li>
                                			&nbsp;&nbsp;&bull;Условия оплаты продукции: 
                                			<?php echo e($order->agreement ? 'Договорные ;' : ''); ?> 
                                			<?php echo e($order->rewrite  ? 'По факту переписки;' : ''); ?>

                                			<?php echo e($order->rewrite  ? 'По факту переписки;' : ''); ?>

                                			</li>
                                			<li>
                                			&nbsp;&nbsp;&bull;Комментарий: 
                                			<?php echo e($order->notice); ?> 
                                			</li>
                                			<li>Разместил пользователь</li>
                                			
                                			<li>&nbsp;&nbsp;&bull;Имя: <?php echo e($order->user->name); ?></li>
                                			<li>&nbsp;&nbsp;&bull;E-mail: <?php echo e($order->user->email); ?></li>
                                			<li>&nbsp;&nbsp;&bull;Телефон: <?php echo e($order->user->phone); ?></li>
                                			<li>&nbsp;&nbsp;&bull;WhatsApp: <?php echo e($order->user->whatssapp); ?></li>
                                		</ul>
                                	</div>
	                                </div>
                                </div>
                                
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


               <!-- <div class="divider-edgewise"></div>-->
            </div>
        
            
        
    </div>
</section>

<div class="range range-xs-center">
<?php echo e($viewdata->appends([
		'filter' => $filter ? 'filter' : '',		
		'arrcorns' => $selected_corns,
		'filterByPriceMin' => $filterByPriceMin,		
		'filterByPriceMax' => $filterByPriceMax,		
		'filterByRegion' => $filterByRegion,		
	])->links()); ?>

</div>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/project.scripts.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>