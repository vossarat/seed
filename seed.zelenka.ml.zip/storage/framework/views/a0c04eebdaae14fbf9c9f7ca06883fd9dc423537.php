<?php $__env->startSection('content'); ?>

<section class="section bg-white text-center index-order">



    <div class="shell">

        <div class="range range-xs-center range-md-left visible-xs">
            <div class="cell-xs-12">

                <form action="<?php echo e(route('order.create')); ?>">
                    <button type="submit" class="button button-effect-ujarak button-block button-primary">
                        Добавить заявку
                    </button>
                </form>

            </div>
        </div>

		
		<?php if(Session::has('message')): ?>
		<div class="alert alert-success">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			<?php echo e(Session::get('message')); ?>

		</div>
		<?php endif; ?>
		

        <h3>
            Заявки
        </h3>

        <div class="row-filter">
        
        	<?php echo $__env->make('order.filter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        	
        </div>
        
                
          
           
            <div class="order-table">
            

                            <?php $__currentLoopData = $viewdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            <?php if(Auth::check() && Auth::user()->id == 1): ?>
	                            <div class="row">
	                            	
	                            	<form action="<?php echo e(route('order.destroy', $order->id)); ?>" method="POST">
									<input type="hidden" name="_method" value="DELETE">
									<?php echo e(csrf_field()); ?>

					                	<button type="submit" class="btn btn-danger">удалить</button>
					                </form>
	                            	
	                            	
	                            </div>
	                            <?php endif; ?>
                            <div class="row order-table-row <?php echo e($order->active ? '' : 'closed'); ?>" id="row-order-<?php echo e($order->id); ?>">
                                <?php if(Auth::check() && Auth::user()->id == $order->user_id): ?>
                                <div class="row">
	                                <div class="col-xs-6">
	                                	<a href="<?php echo e(route('order.edit', $order->id )); ?>">Редактировать</a>
	                                </div>
	                                <div class="col-xs-6">
	                                	<?php if($order->active): ?>
	                                	<a href="#close-order-modal" id="<?php echo e($order->id); ?>" data-toggle="modal" data-backdrop="false" name = "<?php echo e($order->corn['name']); ?>, <?php echo e($order->count . ' тонн'); ?>">Завершить</a>
	                                	<?php else: ?>
	                                	<span style="color: #a94442;"><b>Заявка завершена</b></span>
	                                	<?php endif; ?>
	                                	
	                                </div>
                                </div>
                                <?php endif; ?>
                                
                                <div class="row">
	                                <div class="col-xs-4 text-center" id="created_at_<?php echo e($order->id); ?>">
	                                	<?php echo e(date('d.m.Y',strtotime($order->created_at))); ?>

	                                </div>
	                                <div class="col-xs-4 text-center">
	                                	<?php if(Auth::check() && Auth::user()->id == $order->user_id): ?>
		                                    	Ваша заявка
		                                <?php else: ?>
		                                	<?php if($order->active == 0): ?>
		                                		<span style="color: #a94442;"><b class="text-closed-order">Заявка закрыта</b></span>
		                                	<?php endif; ?>
		                                <?php endif; ?>
	                                </div> 
	                                <div class="col-xs-4 text-center">
	                                	<span id="views_<?php echo e($order->id); ?>" class="fa fa-eye views_order">&nbsp;<?php echo e($order->views); ?></span> 
	                                	
	                                </div>
                                </div>
                                 <div class="row">
	                                <div class="col-xs-12">
	                                	<?php if( $order->active ): ?>
	                                	<a class="toogle-order-detailed" href="/api/views_order/<?php echo e($order->id); ?>" order-id=<?php echo e($order->id); ?>><?php echo e('Куплю:'.$order->corn['name']); ?>, <?php echo e($order->count . ' тонн'); ?></a>
	                                	<?php else: ?>
	                                	<a href="javascript:void(0);"><?php echo e('Куплю:'.$order->corn['name']); ?>, <?php echo e($order->count . ' тонн'); ?></a>
	                                	<?php endif; ?>
	                                <div class="order-detailed toogle-off">
                                		<ul>
                                			<li><u>Цена:</u>
                                				<?php if( Auth::check() ): ?>
                                					<?php echo e($order->price); ?> тенге, <?php echo e($order->loadprice_id ? 'Цена с доставкой' : 'Цена с места'); ?>, <?php echo e($order->auction ? 'Торг' : 'Без торга'); ?>

                                				<?php else: ?>
                                					<a href="/login">*******</a> тенге
                                				<?php endif; ?>
                                			</li>
                                			<li><u>Упаковка:</u> <?php echo e($packs->find($order->pack_id ? $order->pack_id : '1')->name); ?></li>
                                			
                                			
                                			<?php if($order->elevators->count() > 0): ?>
	                                			<li><u>Элеваторы:</u>
	                                				<?php $__currentLoopData = $order->elevators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $elevator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                                					<?php echo e($elevator->title); ?>;
	                                				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                                			</li>
                                			<?php endif; ?>
                                			<li><u>Подробные параметры</u> </li>
                                			<?php if($order->gosts->count() > 0): ?>
	                                		<li>
	                                			&nbsp;&nbsp;&bull;Качество: 
	                                			<?php $__currentLoopData = $order->gosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                                				<?php echo e($gost['name'] . ';'); ?> 
	                                			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                			</li>
                                			<?php endif; ?>
                                			<?php if($order->class_corn ): ?>
	                                			<li>
		                                			&nbsp;&nbsp;&bull;Класс: 
		                                			<?php echo e($order->class_corn); ?> 
	                                			</li>
                                			<?php endif; ?>
                                			<?php if($order->notice ): ?>
	                                			<li>
		                                			&nbsp;&nbsp;&bull;Доп.параметры: 
		                                			<?php echo e($order->notice); ?> 
	                                			</li>
                                			<?php endif; ?>
                                			
                                			
                                			<?php if($order->active): ?>
	                                			<li><u>Разместил пользователь</u></li>
	                                			<?php if(  $order->user->name ): ?>
	                                			<li>&nbsp;&nbsp;&bull;Имя: 
	                                				<?php if( Auth::check() ): ?>
	                                				<?php echo e($order->user->name); ?>

	                                				<?php else: ?>
                                						<a href="/login">*******</a>
                                					<?php endif; ?>
	                                			</li>
	                                			<?php endif; ?>
	                                			<?php if( $order->user->email ): ?>
	                                			<li>&nbsp;&nbsp;&bull;E-mail: 
	                                				<?php if( Auth::check() ): ?>
	                                				<a href="mailto:<?php echo e($order->user->email); ?>"><?php echo e($order->user->email); ?>

	                                				</a>
	                                				<?php else: ?>
	                                					<a href="/login">*******</a>
	                                				<?php endif; ?>
	                                			</li>
	                                			<?php endif; ?>
	                                			<?php if(  $order->user->phone ): ?>
	                                				<li>&nbsp;&nbsp;&bull;Телефон: 
	                                					<?php if( Auth::check() ): ?>
	                                					<?php echo e($order->user->phone); ?>

	                                					<?php else: ?>
	                                						<a href="/login">*******</a>
	                                					<?php endif; ?>
	                                				</li>
	                                			<?php endif; ?>
	                                			<?php if( $order->user->whatsapp ): ?>
	                                			<li>&nbsp;&nbsp;&bull;WhatsApp: 
	                                			<?php if( Auth::check() ): ?>
	                                				<a href="https://wa.me/<?php echo e(Func::phoneOnlyNumber($order->user->whatsapp)); ?>"><?php echo e($order->user->whatsapp); ?></a>
	                                				<?php else: ?>
	                                					<a href="/login">*******</a>
	                                				<?php endif; ?>
	                                				
	                                			</li>
	                                			<?php endif; ?>
                                			<?php endif; ?>
                                			
                                		</ul>
                                	</div>
	                                </div>
                                </div>
                                
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            </div>
         
            
            <div id="more-order-list-2"></div>
            

            
        
    </div>

<!-- HTML-код модального окна -->
<div id="close-order-modal" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- Заголовок модального окна -->
      <div class="modal-header">
        <h4 class="modal-title">Хотитите завершить заявку?</h4>
      </div>
      <!-- Основное содержимое модального окна -->
      <div class="modal-body modal-order-content">
        Вы действительно хотитите завершить заявку ?
      </div>
      <!-- Футер модального окна -->
      <div class="modal-footer row">        
        <button type="button" name="" class="btn btn-primary yes-close-modal col-xs-4 col-xs-offset-2" data-dismiss="modal">Завершить</button>
        <button type="button" class="btn btn-default col-xs-4 col-xs-offset-1" data-dismiss="modal">Отмена</button>
      </div>
    </div>
  </div>
</div>

</section>

<section id="more-order" class="section bg-white text-center"></section>

<section class="section bg-white text-center hidden">
<?php echo e($viewdata->appends([
		'filter' => $filter ? 'filter' : '',		
		'arrcorns' => $selected_corns,
		'filterByPriceMin' => $filterByPriceMin,		
		'filterByPriceMax' => $filterByPriceMax,		
		'filterByRegion' => $filterByRegion,		
	])->links()); ?>

</section>

<section class="section bg-white text-center index-info">
<p>Zelenka. Trade - это уникальный автоматизированный портал, призванный помочь производителям, элеваторам и трейдерам в торговле зерновыми культурами.</p>
<p>С порталом Zelenka.Trade прибыль от Ваших сделок, не уйдет посредникам, Вам больше не придется осуществлять десятки телефонных звонков и тратить время на то, чтобы продать или приобрести зерновые культуры, с помощью данного портала Вы сможете не только расширить границы и возможности Вашего бизнеса, но  и сократить временной цикл сделки до 5 минут.</p>
</section>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/project.scripts.js')); ?>"></script>

<script>
$(document).ready(function() {
	$('#close-order-modal').on('show.bs.modal', function(e) {
	    
	    console.log( $('#views_' + e.relatedTarget.id ).text() );
	    var $modal = $(this),
	        orderName = e.relatedTarget.name;
	        orderId = e.relatedTarget.id;
	        orderViews = $('#views_'+orderId).text();
	        orderCreateDate = $('#created_at_'+orderId).text();
	        
	            contentModal = 	'<div class="row">'+
	            				'<div class="col-xs-6">'+
	            				  orderCreateDate+
	            				'</div>'+
	            				'<div class="col-xs-6">'+
	            				  '<span class="fa fa-eye views_order">'+ orderViews +'</span>' +
	            				'</div>'+
	            				'<div class="col-xs-12">'+
	            				  'Куплю:' + orderName +
	            				'</div>'+
	            				'</div>';
	            //$modal.find('.modal-order-content').html( 'Куплю:' + orderName + '_' +orderViews + '_'+ orderCreateDate );
	            $modal.find('.modal-order-content').html( contentModal );
	            $modal.find('.yes-close-modal').attr("name", orderId);
	    
	});
	
	$('.yes-close-modal').on('click', function(e) {
		orderId = $(this).attr("name");	    
		$.ajax({
		      cache: false,
		      type: 'GET',
		      url: '/api/closed_order/' + orderId,
		      success: function(data)
		      {
				$('#row-order-'+orderId).addClass('closed');
		      }
		  });	    
	});
	
	// парсим строку адрса ссылки чтоб получить номер страницы
	var getLinkParameter = function getLinkParameter(sParam, link) {
		    var sPageURL = decodeURIComponent( link ),
		        sURLVariables = sPageURL.split('&'),
		        sParameterName,
		        i;

		    for (i = 0; i < sURLVariables.length; i++) {
		        sParameterName = sURLVariables[i].split('=');

		        if (sParameterName[0] === sParam) {
		            return sParameterName[1] === undefined ? true : sParameterName[1];
		        }
		    }
		};
	
	
	$('#more-order').append( $('#more-next') ); 
	$('body').on('click', '#more-next', function(e) {
		e.preventDefault();
		var page = getLinkParameter('page', $( this ).attr('href') );
				
		$('#more-order-list-' + page).load( $( this ).attr('href') + ' .order-table' );
		
		$('.order-table').addClass("border-bottom-3px");
		var nextpage = parseInt(page) + 1;
		$('#more-order-list-' + page).after('<div id="more-order-list-' + nextpage + '"></div>');
		$('#more-order').load( $( this ).attr('href') + ' #more-next' ); 
	});
	
	
});
</script>

<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>