<div class="row">		    	
	<div class="col-xs-6">		    	
	<?php if($filter): ?>
		<a href="<?php echo e(route('mapelevator')); ?>" class="button button-effect-ujarak button-block button-default-outline button-filter">
        	Очистить Фильтр
        </a>
    <?php else: ?>			    	
        <a class="button button-effect-ujarak button-block button-default-outline toogle-elevator-filter button-filter">
        	Фильтр
        </a>
    <?php endif; ?>		
	</div>

	<div class="col-xs-6">
		<?php if($fav): ?>
			<a class="button button-effect-ujarak button-block button-default-outline button-filter" href="/mapelevator">Все</a>
		<?php else: ?>
			<a class="button button-effect-ujarak button-block button-default-outline button-filter" href="/mapelevator/fav">Избранные</a>
        <?php endif; ?>
		
	</div>
</div>

<div id="elevator-filter" class="cell-xs-12">	       

    <div class="table-custom-responsive">
        <table class="table-custom">
            <tbody>
                <?php if( isset($filterByRegion) ): ?>
                	<tr>

                        <td>                        	
                        	<a href=" <?php echo e(route('mapelevator').'?filterByState='.$regions->state_id.'&filter=filter&page=1'.$filterByCorn); ?> "><span class="fa fa-long-arrow-left"></span> 
                        		
                        		Акмолинская область 
                        	</a>
                        </td>
                    </tr>
                
                <?php elseif( isset($filterByState) ): ?>
                	<tr>
                        <td>                        	
                        	<a href=" <?php echo e(route('mapelevator').'?filterByState=&filter=filter&page=1'.$filterByCorn); ?> "><span class="fa fa-long-arrow-left"></span> <?php echo e($states->name."  (" .$states->countElevator($states->id). ")"); ?> </a>
                        </td>
                    </tr>                     
                
                    <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                        	
                        	<a href=" <?php echo e(route('mapelevator').'?filterByRegion='.$region->id.'&filter=filter&page=1'.$filterByCorn); ?> "> &nbsp; &nbsp; &nbsp;<?php echo e($region->name."  (" .$region->countElevator($region->id). ")"); ?> <span class="fa fa-long-arrow-right"></span></a>
                        </td>
                    </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <?php else: ?>
                    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	                            
                    <tr>
                        <td>
                        	
                        	<a href=" <?php echo e(route('mapelevator').'?filterByState='.$state->id.'&filter=filter&page=1'.$filterByCorn); ?> "><?php echo e($state->name."  (" .$state->countElevator($state->id). ")"); ?> <span class="fa fa-long-arrow-right"></span> </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?> 
                
            </tbody>

        </table>
    </div>
    
    
    
</div>