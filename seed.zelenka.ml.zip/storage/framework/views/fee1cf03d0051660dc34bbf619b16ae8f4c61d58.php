

<?php if( Auth::check() ): ?>
	<li>
		<a href="<?php echo e(route( "$profile.edit", $profileId)); ?>">Мой профиль</a>
	</li>	

	<li>
		<span>Изменить профиль</span>
		<ul>
          <?php $__currentLoopData = $otherProfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otherProfile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><a href="<?php echo e(route( "$otherProfile[tip].create")); ?>">на <?php echo e($otherProfile['title']); ?></a></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </ul>
	</li>
	
	<li>
        <a href="<?php echo e(route('logout')); ?>"
	        onclick="event.preventDefault();
	        	document.getElementById('logout-form').submit();">
	        <span class="fa fa-sign-out"></span> Выход
	    </a>
	    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
	        <?php echo e(csrf_field()); ?>

	    </form>
    </li>						
<?php else: ?>
	<li>
		<a href="/login">
			Войти в систему
		</a>
	</li>
	<li>
		<a href="/register">
			Регистрация
		</a>
	</li>
<?php endif; ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
	$(function() {
		$('#user-menu').mmenu({
			extensions: ["position-right", "theme-white", "border-full", "shadow-page"],
			navbar			: {
				title			: "<?php echo e($profileTitle); ?>"
			},
			
		});
		
		
		$( ".user-menu" ).click(function( event ) {
			event.preventDefault();				
		});
	});	
</script>
<?php $__env->stopPush(); ?>