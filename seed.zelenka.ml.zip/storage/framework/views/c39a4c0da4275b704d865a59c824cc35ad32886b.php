<!DOCTYPE html>
<html class="wide wow-animation" lang="en">
	<head>
		<meta name="format-detection" content="telephone=no">
	    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta charset="utf-8">
	    <link rel="icon" href="images/favicon.png" type="image/x-icon">

		<title>
			<?php $__env->startSection('title'); ?>
			<?php echo e(isset($title) ? $title : 'Zelenka.Trade'); ?>

			<?php echo $__env->yieldSection(); ?>
		</title>
		
		<!--
		<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Lato:400,700%7CQuattrocento+Sans:400,700">
		-->
		<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed" rel="stylesheet"> 
		
		
		
		<!-- Bootstrap core CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
		
		<!-- Include Font-Awesome -->
		<link rel="stylesheet" href="<?php echo e(asset('css/fonts.css')); ?>">	
		
		<!-- additional CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>" />
		<link rel="stylesheet" href="<?php echo e(asset('css/project-style.css')); ?>" />
		
		<!-- MMENU Style -->
		<link rel="stylesheet" href="<?php echo e(asset('css/jquery.mmenu.all.css')); ?>" />
		
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css">		
		 
		 
		<!-- Include Some Style -->
		<?php echo $__env->yieldPushContent('css'); ?>
		
	</head>

	<body>
	
		<!-- Page-->
    <div class="text-left page">
      <!-- Page preloader-->
      
      <div class="page-loader">
        <div>
          <div class="page-loader-body">
          <img src="/images/preloader.gif" />
           
          </div>
        </div>
      </div>
      
      
      <!-- Page Header-->
      <header class="page-header">
        
        <!-- RD Navbar-->
        <?php $__env->startSection('topbar'); ?>
		    <?php echo $__env->make('layouts.topbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldSection(); ?>
		<!-- /RD Navbar-->
		
      </header>
      
      	<?php echo $__env->yieldContent('tableprice'); ?>
      	
      	<?php echo $__env->yieldContent('content'); ?>
     
      	<!-- News -->
      	<?php $__env->startSection('news'); ?>
		    <?php echo $__env->make('layouts.news', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldSection(); ?>
      	
      
		<!-- Footer -->
	    <?php $__env->startSection('footer'); ?>
		    <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldSection(); ?>
		<!-- /Footer -->
    </div>
    
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    
    <!-- Bootstrap core JavaScript
	================================================== -->
	<script src="<?php echo e(asset('js/core.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/script.js')); ?>"></script>	
	
	<!-- MMENU JavaScript -->
	<script src="<?php echo e(asset('js/jquery.mmenu.all.js')); ?>"></script>
	
	<script src="<?php echo e(asset('js/jquery.maskedinput.js')); ?>"></script>
	<script src="<?php echo e(asset('/js/bootstrap-multiselect.js')); ?>"></script>
	
	
	<?php echo $__env->yieldPushContent('scripts'); ?>
		
	</body>
</html>