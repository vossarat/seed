

<li class="hidden-xs">
    <a href="#">
        <?php echo e($username); ?>

    </a>
    <ul class="rd-navbar-dropdown">
        <?php if( Auth::check() ): ?>
			<li>
				<?php if( $profile_type === 'trader'): ?>
					<?php if( $profile_action === 'create' ): ?>
						<a href="<?php echo e(route('trader.create')); ?>">Мой профиль</a>
					<?php else: ?>
						<a href="<?php echo e(route('trader.edit', $profile_id)); ?>">Мой профиль</a>
					<?php endif; ?>
				<?php else: ?>
					<?php if( $profile_action === 'create' ): ?>
						<a href="<?php echo e(route('farmer.create')); ?>">Мой профиль</a>
					<?php else: ?>
						<a href="<?php echo e(route('farmer.edit', $profile_id)); ?>">Мой профиль</a>
					<?php endif; ?>
				<?php endif; ?>
			</li>
			
			
			
			<?php if( Auth::user()->id === 1 ): ?>
			<li>
                <a href="/dashboard">Админ.панель</a>
            </li>
            <?php endif; ?>

			<li>
	            <a href="<?php echo e(route('logout')); ?>"
	                onclick="event.preventDefault();
	                	document.getElementById('logout-form').submit();">
	                <span class="fa fa-sign-out"></span> Выход
	            </a>
	            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
	                <?php echo e(csrf_field()); ?>

	            </form>
	        </li>						
		<?php else: ?>
			<li>
				<a href="/login">
					Войти в систему
				</a>
			</li>
			<li>
				<a href="/register">
					Регистрация
				</a>
			</li>
	   	<?php endif; ?>
    </ul>
</li>