
 
 <p>
 	<?php echo e($username); ?>

 </p> 
 
 <nav class="navbar navbar-default usermenu" role="navigation">
	<ul class="nav navbar-nav">
	    <li class="dropdown usermenu-dropdown"> 
	        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
	        	Личный кабинет<b class="caret"></b>
	        </a>
	        <ul class="dropdown-menu">
	            <?php if( Auth::user()->id === 1 ): ?>
					<li>
		                 <a href="<?php echo e(route('dashboard')); ?>">Админ.панель</a>
		            </li>
		            <li class="divider"></li> <!--Separator-->
		        <?php endif; ?>
	            

				<li>
					<a href="<?php echo e(route( "$profile.edit", $profileId)); ?>">Мой профиль</a>
				</li>
				
				<?php $__currentLoopData = $otherProfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otherProfile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li>
					<a href="<?php echo e(route( "$otherProfile[tip].create")); ?>">Изменить на <?php echo e($otherProfile['title']); ?></a>
				</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<li class="divider"></li> <!--Separator-->
				
				<li>
		            <a href="<?php echo e(route('logout')); ?>"
				        onclick="event.preventDefault();
				        	document.getElementById('logout-form').submit();">
				        <span class="fa fa-sign-out"></span> Выход
				    </a>
				    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
				        <?php echo e(csrf_field()); ?>

				    </form>
		        </li>                        
	        </ul>
	    </li>              
	                   
	</ul>
</nav>