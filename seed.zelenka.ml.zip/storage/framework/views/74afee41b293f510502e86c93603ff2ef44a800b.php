
 <p>
 	<?php echo e($username); ?>

 </p>
 <?php if( Auth::user()->id === 1 ): ?>
	<p>
        <a href="<?php echo e(route('dashboard')); ?>">Админ.панель</a>
    </p>
<?php endif; ?>
    
<p>
	<?php if( $profile_type === 'trader'): ?>
		<?php if( $profile_action === 'create' ): ?>
			<a href="<?php echo e(route('trader.create')); ?>">Мой профиль</a>
		<?php else: ?>
			<a href="<?php echo e(route('trader.edit', $profile_id)); ?>">Мой профиль</a>
		<?php endif; ?>
	<?php else: ?>
		<?php if( $profile_action === 'create' ): ?>
			<a href="<?php echo e(route('farmer.create')); ?>">Мой профиль</a>
		<?php else: ?>
			<a href="<?php echo e(route('farmer.edit', $profile_id)); ?>">Мой профиль</a>
		<?php endif; ?>
	<?php endif; ?>
</p>


<p>
    <a href="<?php echo e(route('logout')); ?>"
        onclick="event.preventDefault();
        	document.getElementById('logout-form').submit();">
        <span class="fa fa-sign-out"></span> Выход
    </a>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo e(csrf_field()); ?>

    </form>
</p>      
 
 
