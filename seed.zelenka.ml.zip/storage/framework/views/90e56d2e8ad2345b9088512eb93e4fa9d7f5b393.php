<div class="rd-navbar-nav-wrap">
    <!-- RD Navbar Nav-->
    <ul class="rd-navbar-nav">
        
        	<li>
                <a href="<?php echo e(route('order.index')); ?>">
                    <?php echo app('translator')->getFromJson('topmenu.mainpage'); ?>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('order.create')); ?>">
                    <?php echo app('translator')->getFromJson('topmenu.addorder'); ?>
                </a>
            </li>
              
        
        <li>
            <a href="<?php echo e(route('mapelevator')); ?>">                
                <?php echo app('translator')->getFromJson('topmenu.elevators'); ?>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('news')); ?>">                
                <?php echo app('translator')->getFromJson('topmenu.news'); ?>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('feedback')); ?>">
                <?php echo app('translator')->getFromJson('topmenu.feedback'); ?>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('help')); ?>">
                <?php echo app('translator')->getFromJson('topmenu.help'); ?>
            </a>
        </li>
        <li class="visible-xs">
            <p class="text-center" style="color: #f8a63d;">
                Зарегистрировано
            </p>
            <div class="count-user">
	            <p>
	                Трейдеры : <?php echo e($cntTrader); ?>

	            </p>
	            <p>
	                Производители СПХ : <?php echo e($cntFarmer); ?>

	            </p>
	            <p>
	                Элеваторы : <?php echo e($cntElevator); ?>

	            </p>
            </div>
        </li>
       
        	

    </ul>
</div>