<div class="rd-navbar-nav-wrap">
    <!-- RD Navbar Nav-->
    <ul class="rd-navbar-nav">
        <li>
            <a href="#">
                Заявки
            </a>
            <ul class="rd-navbar-dropdown">
                <li>
                    <a href="<?php echo e(route('order.create')); ?>">
                        Добавить заявку
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('order.index')); ?>">
                        Все заявки
                    </a>
                </li>
            </ul>
        </li>
       
        <li>
            <a href="<?php echo e(route('mapelevator')); ?>">
                Карта элеваторов
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('xxx')); ?>">
                Новости
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('feedback')); ?>">
                Обратная связь
            </a>
        </li>
        
        <!-- Секция меню  пользователя -->
        <?php $__env->startSection('usermenu'); ?>
        	<?php echo $__env->make('layouts.usermenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldSection(); ?>
    </ul>
</div>