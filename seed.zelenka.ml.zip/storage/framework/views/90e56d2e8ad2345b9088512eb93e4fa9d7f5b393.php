<div class="rd-navbar-nav-wrap">
    <!-- RD Navbar Nav-->
    <ul class="rd-navbar-nav">
        
        	<li>
                <a href="<?php echo e(route('order.index')); ?>">
                    Главная
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('order.create')); ?>">
                    Добавить заявку
                </a>
            </li>
              
        
        <li>
            <a href="<?php echo e(route('mapelevator')); ?>">
                Элеваторы
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('news')); ?>">
                Новости
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('feedback')); ?>">
                Обратная связь
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('help')); ?>">
                Помощь
            </a>
        </li>

    </ul>
</div>