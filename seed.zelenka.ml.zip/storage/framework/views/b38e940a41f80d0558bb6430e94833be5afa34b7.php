<?php $__env->startSection('tableprice'); ?>
    <?php echo $__env->make('layouts.tableprice', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>



<section class="section bg-white text-center">

<div class="shell">

    <h3>
        Карта элеваторов
    </h3>
    
   
    <div class="row-filter">
        
        <?php echo $__env->make('elevator.filter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        	
    </div>
    
    
    <div class="order-table">

            <?php $__currentLoopData = $viewdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $elevator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row order-table-row">
            	<div class="row">
                    <div class="col-xs-2 col-fav-elevator">
                    	
                    	<?php if(Auth::check()): ?>
                    		<span id="fav-<?php echo e($elevator->id); ?>" class="fav <?php echo e($elevator->fav); ?>"></span>
                    	<?php endif; ?> 
                    </div>
                    <div class="col-xs-5 text-left">
                    		<?php echo e(mb_strlen($elevator->region_name, 'utf-8') > 18 ? mb_substr($elevator->region_name, 0, 15).'...' : $elevator->region_name); ?>

                    </div>
                    <div class="col-xs-5">
                    	<?php echo e($elevator->price); ?>

                    </div>
                </div>
                
                <div class="row">
                    <div class="col-xs-12">
                    	<a class="toogle-order-detailed" href="#">
                    		<?php echo e($elevator->title); ?>

                    	</a>
                    	<div class="order-detailed toogle-off">
                    		<ul>
                    			<?php if($elevator->corns->count() > 0): ?>
	                    			<li><u>Принимает культуры:</u>                    				
	                    				<?php $__currentLoopData = $elevator->corns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $corn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                    					<?php echo e($corn->name); ?>;
	                    				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	                    			
	                    			</li>
                    			<?php endif; ?>
                    			<li><u>Контактные данные</u></li>                                			
                        			<?php if($elevator->username): ?>
                        				<li>&nbsp;&nbsp;&bull;Контактное лицо : <?php echo e($elevator->username); ?></li>
                        			<?php endif; ?>
                        			<?php if($elevator->email): ?>
                        			<li>&nbsp;&nbsp;&bull;E-mail: <?php echo e($elevator->email); ?></li>
                        			<?php endif; ?>
                        			<?php if($elevator->phone): ?>
                        				<li>&nbsp;&nbsp;&bull;Телефон: <?php echo e($elevator->phone); ?></li>
                        			<?php endif; ?>
                        			<?php if($elevator->whatssapp): ?>
                        				<li>&nbsp;&nbsp;&bull;WhatsApp: <?php echo e($elevator->whatssapp); ?></li>
                        			<?php endif; ?>
                        		<?php if($elevator->attributes->count() > 0): ?>
	                    			<li><u>Услуги:</u>                    				
	                    				<?php $__currentLoopData = $elevator->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                    					<?php if($attribute->pivot->attr_value != ''): ?>
	                    					<?php echo e($attribute->name); ?> - <?php echo e($attribute->pivot->attr_value); ?>;
	                    					<?php endif; ?>
	                    				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	                    			
	                    			</li>
                    			<?php endif; ?>

                    		</ul>
                    	</div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            

    </div>
    
    <div id="more-elevator-list-2"></div>      
    
</div>
</section>

<section id="more-elevator" class="section bg-white text-center"></section>

<section class="section bg-white text-center hidden">
<?php echo e($viewdata->appends([
		'filter' => $filter ? 'filter' : '',		
		'arrcorns' => $selected_corns,		
		'filterByPriceMin' => $filterByPriceMin,		
		'filterByPriceMax' => $filterByPriceMax,		
	])->links()); ?>

</section>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/project.scripts.js')); ?>"></script>
<script>
$(document).ready(function() {
            
        $( ".fav" ).click(function( event ) {
                var elevator_id = $(this).attr('id').substring(4);
                console.log( 'elevator_id = '+elevator_id );
                
                var url_action = "/api/fav/remove/"+<?php echo e(Auth::id() ?  Auth::id() : 0); ?>+"/"+elevator_id ; 
                if( $(this).hasClass("fa-star-o") ) {
					 
					 url_action = "/api/fav/add/"+<?php echo e(Auth::id() ?  Auth::id() : 0); ?>+"/"+elevator_id ;
					 $(this).removeClass("fa-star-o");
					 $(this).addClass("fa-star"); // ставим избранное
				} else {
					$(this).removeClass("fa-star"); // убираем избранное
					$(this).addClass("fa-star-o");
				}
				console.log( 'url_action = '+url_action );
                $.ajax({
                        url: url_action,
                    });
            });
            
        // парсим строку адрса ссылки чтоб получить номер страницы
		var getLinkParameter = function getLinkParameter(sParam, link) {
			    var sPageURL = decodeURIComponent( link ),
			        sURLVariables = sPageURL.split('&'),
			        sParameterName,
			        i;

			    for (i = 0; i < sURLVariables.length; i++) {
			        sParameterName = sURLVariables[i].split('=');

			        if (sParameterName[0] === sParam) {
			            return sParameterName[1] === undefined ? true : sParameterName[1];
			        }
			    }
			};
		
		
		$('#more-elevator').append( $('#more-next') ); 
		$('body').on('click', '#more-next', function(e) {
			e.preventDefault();
			var page = getLinkParameter('page', $( this ).attr('href') );
					
			$('#more-elevator-list-' + page).load( $( this ).attr('href') + ' .order-table' );
			
			$('.order-table').addClass("border-bottom-3px");
			var nextpage = parseInt(page) + 1;
			$('#more-elevator-list-' + page).after('<div id="more-elevator-list-' + nextpage + '"></div>');
			$('#more-elevator').load( $( this ).attr('href') + ' #more-next' ); 
		});
});
</script>
<?php $__env->stopPush(); ?>	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>