<?php

namespace App\Reference;

use Illuminate\Database\Eloquent\Model;

class Pack extends Model
{
    //
}
