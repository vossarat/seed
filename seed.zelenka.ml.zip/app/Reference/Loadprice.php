<?php

namespace App\Reference;

use Illuminate\Database\Eloquent\Model;

class Loadprice extends Model
{
    //
}
